"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 4244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/Layout.jsx
var Layout = __webpack_require__(7267);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-infinite-scroller"
const external_react_infinite_scroller_namespaceObject = require("react-infinite-scroller");
var external_react_infinite_scroller_default = /*#__PURE__*/__webpack_require__.n(external_react_infinite_scroller_namespaceObject);
;// CONCATENATED MODULE: ./pages/index.jsx









function Home({ initialPokemon  }) {
    console.log(initialPokemon);
    const [pokemon, setPokemon] = (0,external_react_.useState)(initialPokemon);
    const [hasMore, setHasMore] = (0,external_react_.useState)(true);
    const [category, setCategory] = (0,external_react_.useState)("");
    const [offset, setOffset] = (0,external_react_.useState)(0);
    const [limit, setLimit] = (0,external_react_.useState)(50);
    const [val, setValue] = (0,external_react_.useState)("");
    // Fungsi loadmore, nambah 15 setiap kali scroll kebawah
    const loadMore = async ()=>{
        if (category) {
            const res = await fetch(`https://pokeapi.co/api/v2/type/${category}`);
            const { pokemon: newPokemon  } = await res.json();
            setPokemon((prev)=>[
                    ...prev,
                    ...newPokemon
                ]);
        } else {
            const res = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${limit}&offset=${offset}`);
            const { results  } = await res.json();
            const newPokemon = results.map((pokemon, index)=>{
                const paddedId = ("00" + (index + 1)).slice(-3);
                const image = `https://assets.pokemon.com/assets/cms2/img/pokedex/detail/${paddedId}.png`;
                return {
                    ...pokemon,
                    image
                };
            });
            setPokemon((prev)=>[
                    ...prev,
                    ...newPokemon
                ]);
            setOffset((prev)=>prev + limit);
        }
    };
    const ss = async ()=>{};
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        title: "Pokedex by Naufal Ihsan",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-4xl mb-8 text-center",
                children: "Pokedex"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center my-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                            className: "border p-2 rounded-md",
                            onChange: (e)=>setValue(e.target.value),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "",
                                    children: "All"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "1",
                                    children: "Normal"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "2",
                                    children: "Fighting"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "3",
                                    children: "Flying"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_infinite_scroller_default()), {
                        pageStart: 0,
                        loadMore: loadMore,
                        hasMore: hasMore,
                        loader: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: "Loading ..."
                        }, 0),
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-wrap justify-center",
                            children: pokemon?.map((pokeman, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-full md:w-1/3 lg:w-4/4 px-3 mb-4 ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: `/pokemon?id=${index + 1}`,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "border p-4 border-grey my-2 hover:shadow-lg hover:bg-green-100 capitalize flex items-center text-lg bg-gray-200 rounded-md w-ful",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: pokeman?.image,
                                                    alt: pokeman.name,
                                                    className: "w-20 h-20 mr-3"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "mr-2 font-bold",
                                                    children: [
                                                        index + 1,
                                                        "."
                                                    ]
                                                }),
                                                pokeman.name
                                            ]
                                        })
                                    })
                                }, index))
                        })
                    })
                ]
            })
        ]
    });
}
async function getStaticProps() {
    try {
        const res = await fetch("https://pokeapi.co/api/v2/pokemon?limit=25");
        const { results  } = await res.json();
        const initialPokemon = results.map((pokemon, index)=>{
            const paddedId = ("00" + (index + 1)).slice(-3); //00n
            const image = `https://assets.pokemon.com/assets/cms2/img/pokedex/detail/${paddedId}.png`;
            return {
                ...pokemon,
                image
            };
        });
        return {
            props: {
                initialPokemon
            }
        };
    } catch (err) {
        console.error(err);
    }
}


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [443,61,267], () => (__webpack_exec__(4244)));
module.exports = __webpack_exports__;

})();